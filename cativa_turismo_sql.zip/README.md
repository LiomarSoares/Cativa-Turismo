# Projeto Cativa Turismo SQL

Repositório contendo scripts SQL para criação, inserção, consultas, atualização e exclusão de dados no banco de dados da agência Cativa Turismo.
